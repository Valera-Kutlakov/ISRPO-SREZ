﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace Blind_Cat.Classes
{
    internal class Sale
    {
        [JsonPropertyName("DateSale")]
        public DateTime DateSale { get; set; }

        [JsonPropertyName("Client")]
        public Client Client { get; set; }

        [JsonPropertyName("Telephones")]
        public List<Telephone> Telephones { get; set; }
    }
}
